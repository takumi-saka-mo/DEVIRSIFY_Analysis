import setuptools

print(setuptools.find_packages(where="src"))